//package com.ingdirect.dg.util;

//Standard Java

//Third party

//ING DIRECT

/**
 * This class validates a given address
 * using Group1 Universal Coder System located on an ING server.
 *
 * Rather then invoking the G1 objects directly, this code will
 * invoke Facade objects, which front the real objects.  This is
 * done to implement Mock Objects.
 *
 * The basic design follows :
 *
 * A Facade object is created for each G1 object by
 * defining each of the g1 object methods.  Behind each method,
 * the G1 method will be directly invoked.
 *
 * A Mock object will EXTEND the Facade object and override
 * each method.
 *
 * A FacadeFactory object will produce either a G1 facade or
 * a Mock facade by sensing if the code is being tested.
 *
 * Notes :
 *    1. This code was written to replace the G1AddressValidator code, as such,
 *       it honors its interfaces and results, so that this new code will have
 *       no impact on existing code.
 *
 * @author abrida
 * @version $Revision: 2976 $
 */
public class AddressValidatorG1UnivCoder implements AddressValidator {

    //** The name of the class and the name used by the logger. */
    final static String CLASS_ID = AddressValidatorG1UnivCoder.class.getName();
    final static String logName = CLASS_ID;
    final static Logger log = Logger.getLogger(logName);
    //** portion of key name to retrieve all like connection key,values */
    final static String SUB_NAMED_CONNECTIONS = "g1.connection.";

    //** portion of key name to retrieve all like message option key,values */
    final static String SUB_NAMED_OPTIONS = "g1.Message.Option.";

    //** key name to retrieve the name of the validataAddress service */
    final static String NAMED_SERVICE = "g1.server.service.validateAddress";

    //** the name of the service retrieved with key name defined by NAMED_SERVICE
    final static String SERVICE;

    //** Property file that contains all the connection properties */
    final static Properties CONNECTION_PROPERTIES;

    //** Property file that contains all the message option properties */
    final static Properties MESSAGE_PROPERTIES;

    //static initialization
    static {
        // retrieves the name of the G1Service
        SERVICE = ApplicationProperties.getProperty(NAMED_SERVICE);
        // retrieves all of the connection properties
        CONNECTION_PROPERTIES = ApplicationProperties.getSubProperties(SUB_NAMED_CONNECTIONS, true);
        // retrieves all of the message options
        MESSAGE_PROPERTIES = ApplicationProperties.getSubProperties(SUB_NAMED_OPTIONS, true);
    }

    /**
     * Default Constructor
     */
    public AddressValidatorG1UnivCoder() {
        super();
    }

   /**
     * This method is intended to be ran from a JUNIT test to
     * test the integrity of this class.
     *
     * @param inAddress - the address to be tested
     * @return String   - a formatted string that bears the results of the test.
     */
    public String selfTest(BasicAddress inAddress) {
        log.finest("Starting");
        String resultCode;

        //If no address is define, supply one
        if (inAddress == null) {
            inAddress = new BasicAddress("8 Birch Knoll Rd", "", null, "Wilmington", new UsState("DE"), "19810");
        }

        log.finest("Validating Address: " + inAddress.toString());

        //Get an object for this class
        AddressValidator av = new AddressValidatorG1UnivCoder();
        PostalAddress[] outAddress;

        //Process the given address and format the result
        try {
            outAddress = av.getStandardAddress(inAddress);
            resultCode = G1StandardAddress.testResult((G1StandardAddress[]) outAddress);
        }
        catch (Exception exception) {
            resultCode = "X";
            log.severe("Unexpected Error:\n" + ExceptionUtil.getStackTrace(exception));
        }

        return resultCode;
    }
    
} //~~    