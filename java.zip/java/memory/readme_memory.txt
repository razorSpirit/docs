
The jsp page was found at : http://www.freshblurbs.com/explaining-java-lang-outofmemoryerror-permgen-space

jprobe
------
 licensed tool.  Great graphics.

  https://wiki/wiki/index.php/Running_JProbe_with_Webtop


visualvm.exe
------------
  similar to jconsole.  included in jdk. also standalone version.

jconsole.exe
------------
 Monitors threads, memory, changes jmx properties, takes thread dump

 1. add the following to the jvm argruments:

-Dcom.sun.management.jmxremote
-Dcom.sun.management.jmxremote.port=9006
-Dcom.sun.management.jmxremote.authenticate=false
-Dcom.sun.management.jmxremote.ssl=false

 2. From the JDK run jconsole


helpful windows commands 
-------------------------

Determines what services are running and their PID :  tasklist /svc
Thread dump                                        :  jmap -heap:format=b -d64 <jvm pid>



-------------------------

http://publib.boulder.ibm.com/infocenter/wasinfo/v6r0/index.jsp?topic=/com.ibm.websphere.express.doc/info/exp/ae/tprf_tunejvm.html

-XX:PermSize
The section of the heap reserved for the permanent generation holds all of the reflective data for the JVM. 
This size should be increased to optimize the performance of applications that dynamically load and 
unload a lot of classes. Setting this to a value of 128MB eliminates the overhead of 
increasing this part of the heap.

http://www.freshblurbs.com/explaining-java-lang-outofmemoryerror-permgen-space

There is a third generation too - Permanent Generation. The permanent generation is special because it holds
 meta-data describing user classes (classes that are not part of the Java language). Examples of such meta-data 
are objects describing classes and methods and they are stored in the Permanent Generation. 
Applications with large code-base can quickly fill up this segment of the heap which will 
cause java.lang.OutOfMemoryError: PermGen no matter how high your 
-Xmx and how much memory you have on the machine


06.  cannot run jmap with windows service
http://forums.oracle.com/forums/thread.jspa?threadID=1175542&tstart=60
