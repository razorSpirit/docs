package com.ingdirect.util.threading;

/**
 * Interface to provide a callback mechanism for 
 * posting objects .
 * 
 * @author abrida
 * @version $Revision: 409 $
 */
public interface IndexedObjectCallback {
	void onIndexedObjectComplete(int index, Object object, String comments);
}
