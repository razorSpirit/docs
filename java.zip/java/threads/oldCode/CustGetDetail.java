package com.ingdirect.dg.service;

// Standard Java 
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Logger;
import java.util.logging.Level;
//   Third Party
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
// ING Direct
import com.ingdirect.util.log.PerfLog2;
import com.ingdirect.util.xml.SimpleElement;
import com.ingdirect.util.xml.SimpleBooleanElement;
import com.ingdirect.util.xml.ThreadLocalDocumentBuilder;
import com.ingdirect.util.rules.RuleEngineImpl;
import com.ingdirect.util.rules.RuleResult;
import com.ingdirect.util.rules.ElectricOrangeEligibilityRule;
import com.ingdirect.util.rules.Rule;
import com.ingdirect.util.rules.RuleConstants;
import com.ingdirect.util.threading.IndexedObjectCallback;
import com.ingdirect.util.threading.ThreadsTimer;
import com.ingdirect.dg.DirectGatewayException;
import com.ingdirect.dg.util.JdbcHelper;
import com.ingdirect.dg.util.Restrictions;
import com.ingdirect.dg.util.GetCustDetailData;
import com.ingdirect.dg.util.CustDetailRequestor;
import com.ingdirect.dg.util.CustSummariesRequestor;
import com.ingdirect.dg.util.CustExternalLinksRequestor;
import com.ingdirect.dg.util.CustHelper;
import com.ingdirect.dg.xmlbind.AutoMarshallGatewayMessage;
import com.ingdirect.dg.xmlbind.GatewayMessage;

import com.ingdirect.dg.xmlbind.data.CustId;
import com.ingdirect.dg.xmlbind.data.CustDetail;

/**
 * Process requests for obtaining detailed customer information. This
 * service supports requests up to detail level 3. It responds with
 * a GatewayMessage containing a urn:gw-customer-100 Detail element.
 *
 * Electric Orange Eligibility processing requires the retrieval 
 * of both Summaries and External Links to determine a customers eligbility.
 * In addition, each related customer's Electric Orange Eligibility must be determined.
 * To accomplish this requirement, an inner class, ElectricOrangeEligibilityAssessment,
 * is instantiated on a separate Thread. And ElectricOrangeEligibilityAssessment fires
 * separate threads to retrieve Detail, Summaries and External Links.  
 *
 * These threads are all managed by the ThreadsTimer class which collects and
 * fires each thread, then sleeps until the threads have completed running or 
 * time has expired.   
 * 
 * @version $Revision: 637 $
 */
public class CustGetDetail extends SimpleAbstractService {
	// Logger name.
	private static final String LOG_NAME = "com.ingdirect.dg.service.CustGetDetail";
	
	// ============== Static Fields ===================
	private Logger log = Logger.getLogger(LOG_NAME);	
	
	private static final String PROFILE_DATABASE = "account";
	public static final String ARG_REQUEST_MAP = "p.reqMap";
	public static final String ARG_RESPONSE_MAP = "p.respMap";
	private static final String ARG_PRIMARY_ACCOUNT = "p.PrimaryAccount";
	private static final String ARG_RGW_MESSAGE = "p.reqGWMsg";
	public static final String ARG_ELECTRIC_ORANGE = "p.electricOrange";
	public static final String TYPE_ELECTRIC_ORANGE = RuleConstants.APP_EO_ACCOUNT_TYPE_NAME;
	
	// ============== Object Fields ===================
	private static PerfLog2 perfLog = new PerfLog2();	
	
	//-- Object to manage synchronization of EOEligibility thread(s) callback --
	Object EoEligibilityMutex = new Byte((byte)0);	

	//-- time (millis) to interrupt sleep to interrogate completion --
	private final int EO_TIME_TO_WAKE_UP = 500;
	//-- time (millis) to wait for a timeout (6 seconds)
	private final int EO_TIME_OUT_TO_WAIT = (1000*6);
	//-- number of timeouts --
	private final int EO_TIME_OUT_COUNT = 3;
	
	/** Array containing results of Electric Orange Eligility
	 *  Position 0     - represents the customer
	 *  Positions 1-n  - represent related customers
	 * 
	 *  value 0 - not eligible
	 *        1 - is eligible
	 */ 
	private int [] electricOrangeResults;

	/**
	 * Base name for per-service configuration.
	 */
	protected String configBaseName() {
		return "CustGetDetail";
	}

	
	/**
	 * The heart of the service, this is passed an XML input (the request)
	 * and returns the XML output. It is also passed the name of the
	 * transaction, and maps of request and response options.
	 * <p>
	 * This method handles the XML marshalling and unmarshalling, but it
	 * invokes {@see CustGetDetail#processService} to obtain the actual
	 * data.
	 */
	public String execute(String transaction, 
	                      String request, 
						  Map requestOptions, 
						  Map responseOptions
	)
		throws DirectGatewayException
	{
		try {
			// NOTE: The CustGetDetail (for now) is used for only one transaction,
			//  so we won't bother to verify that the transaction is "GetCustDetail".

			// -- Review input XML --
			AutoMarshallGatewayMessage reqGwMsg = new AutoMarshallGatewayMessage();
			unmarshall(request, requestOptions, reqGwMsg);
			CustId reqData = new CustId();
			reqGwMsg.fillBodyData(reqData);
			
			// -- Obtain all the data --
			CustDetail resultData = processService(reqData);
			
			// -- Prepare response XML --
			AutoMarshallGatewayMessage gwMsg = new AutoMarshallGatewayMessage();
			gwMsg.initNew();
			gwMsg.setResponse();
			gwMsg.setResponseType(AutoMarshallGatewayMessage.RESTYPE_RESULT);
			gwMsg.setBodyData( resultData, "Detail" ); // Detail is the name of the body element tag
			String responseString =  marshall(gwMsg, responseOptions);
			
			/**
			 * If we are in the middle of processing Electric Orange then we
			 * are interested only in getting the Detail, so we can skip the
			 * following code.
			 */
			if( ! requestOptions.containsKey( ARG_ELECTRIC_ORANGE ) ){
				String cif = reqData.CIF.toString();
				
				//Signal that we are processing Electric Orange
				// Note we must copy the map because it is not modifiable.
				//
				Map options = new HashMap();
				options.putAll(requestOptions);
				options.put(ARG_ELECTRIC_ORANGE, "1");
				
				//Assess Electric Orange Eligibility for CIF and each related customer
				try{
					responseString = processElectricOrange(resultData, responseString, options, responseOptions, cif, reqData.Lang._value, reqGwMsg );
				} catch(Exception exception){
					log.warning("100-Electric Orange Processing for cif("+cif+") throwing an error.");
					throw exception;					
				} 
			}
			
			// -- done --
			return responseString;
		} catch(Exception err) {
			// Superclass takes care of this, including logging.
			return generateError(err, responseOptions);
		}
	}
	

	
	/**
	 * This is where the data is really obtained.
	 */
	private CustDetail processService(CustId reqData) 
		throws java.text.ParseException, DirectGatewayException, SQLException
	{
		String cifStr;
		try {
			cifStr = reqData.CIF.toString();
			Integer.parseInt( cifStr );
		} catch(Exception err) {
			// could not convert CIF to string (or it was absent)
			throw new DirectGatewayException("Invalid request: must contain valid CIF.");
		}

			
		CustDetail resData = new CustDetail();
		
		resData.CIF = new SimpleElement(cifStr);
		resData.DetailLevel = new SimpleElement("3");
		
		GetCustDetailData.getCustDataFromEdge(reqData, resData);
		if(!resData.Status.toString().equals("visitor")) {
			getDataFromProfile(reqData, resData);
		 } else {
			log.finest("Customer is a vistor.");
		}
		
		//Add Electric Orange Invite
		addElectricOrangeInvite(cifStr, resData);
		
		return resData;
	}
	
	
	/**
	 * Subroutine of processService() that obtains data from profile.
	 */
	public static void getDataFromProfile(CustId reqData, CustDetail resData) 
		throws SQLException, DirectGatewayException
	{
		String cif = reqData.CIF.toString();
		
		Connection connection = null;
		try {
			connection = JdbcHelper.getConnection(PROFILE_DATABASE);
			connection.setAutoCommit(true);
			Statement statement = connection.createStatement();
			
			// -------- CIF QUERY --------
			// Perform this query first because if there is no customer data, then there
			// is no reason to check the restrictions table.
			perfLog.startProfileSql("queryCifForCustDetail");
			ResultSet rs = statement.executeQuery(
							"select ZELCDLV,ZPINBLK,DOD,BWF,W9STAT,PIN,ZEDDN from CIF where ACN = " + cif);
			perfLog.stop(true);
			
			if (! rs.next()) {
				// There is no profile entry for this CIF (probably a Visitor).
				connection.close();
				connection = null;
				return;
			}

			// See if electronic statements are allowed
			resData.CustElections.ElectronicStatements = new SimpleBooleanElement( rs.getBoolean(1) );
			//zeddn column is defined as numeric on profile. If zeddn column is null or 0, 
			//then customer has not signed up with EDDN.			
			resData.CustElections.AcceptedEDDN = new SimpleBooleanElement(rs.getInt(7)!=0);

			// Check PIN status
			boolean pinBlocked = rs.getBoolean(2);
			boolean pinSet = rs.getString(6).length() > 0;
			if(pinSet && !pinBlocked) {
				resData.SecurityStatus.PinOk = new SimpleBooleanElement(true);
				resData.SecurityStatus.PinStatus = new SimpleElement("ok");
			 }
			 else {
				resData.SecurityStatus.PinOk = new SimpleBooleanElement(false);
				if(pinSet) {
					resData.SecurityStatus.PinStatus = new SimpleElement("notActivated");
				 }
				 else {
					resData.SecurityStatus.PinStatus = new SimpleElement("notSet");
				 }
			 }
	
			// Tax status		
			if(rs.getBoolean(4)) {
				resData.TaxStatus = new SimpleElement("withhold");
			 }
			 //!else check W9 status
			 else {
				String w9Stat = rs.getString(5);
				if (w9Stat == null || w9Stat.trim().length() == 0 || w9Stat.trim().equals("0"))
					resData.TaxStatus = new SimpleElement("ok");
				else
					resData.TaxStatus = new SimpleElement("needInfo");

			 }
			
			if (rs.next()) {
				throw new DirectGatewayException("More than one row returned " +
				    "from CIF table in Profile for CIF of " + cif);
			}

			// -------- Restrictions QUERY --------
		
			perfLog.startProfileSql("queryCifRestrictions");	
			rs = statement.executeQuery("select RFLG from RFLGC where ACN = " + cif);
			perfLog.stop(true);
			
			List restrictions = new ArrayList();
			while(rs.next()) {
				CustDetail.Restriction r = new CustDetail.Restriction();
				String restrictionCode = "CIF" + rs.getString(1);
				Restrictions.Restriction restriction;
				try {
					restriction = Restrictions.restrictionFromCode(restrictionCode);
				} catch(Restrictions.InvalidRestrictionCodeException err) {
					throw new DirectGatewayException(
						"RestrictionCode of " + restrictionCode + 
						" is not a known code. Was returned from Profile in " +
						"query for customer " + cif);
				}
				 
				r.RestrictionCode = new SimpleElement( restrictionCode );
				r.RestrictionName = new CustDetail.Restriction.RestrictionName();
				r.RestrictionName._value = restriction.getDescription();
				    
				// We can't select the desired language, so don't specify what language we're using
				r.RestrictionName.lang = null;
				restrictions.add(r);
			}
			
			// Convert the list of Restriction objects into an array and use it.
			resData.Restriction = new CustDetail.Restriction[restrictions.size()];
			restrictions.toArray(resData.Restriction);

			connection.close();
			connection = null;
			
		} finally {
			perfLog.stop(false);
			if(connection != null) connection.close();
		}
	}
	
	/**
	 * Adds an Electric Orange Invitation to the Invitations in CustDetail
	 * @param cif
	 * @param resData
	 */ 
	private void addElectricOrangeInvite(String cif, CustDetail resData){
		
		boolean ok;
		try{
			ok = CustHelper.isRestrictedElementBetweenDate(cif,TYPE_ELECTRIC_ORANGE, null);
		} catch(Exception exception){
			ok = false;
			log.severe("Exception for Electric Orange Invite.\n"+exception.toString());
		}
		
		//Create the new entry
		CustDetail.Invitation invitation = new CustDetail.Invitation();
		invitation.InvitationType = new SimpleElement(TYPE_ELECTRIC_ORANGE);
		invitation.Invited = new SimpleBooleanElement(ok);
		
		//-- Add the new entry to the array --
		CustDetail.Invitation[] invitations = resData.Invitations;
		int size = 0;
		if( invitations != null){
			size = invitations.length;
		}
		
		//-- Expand the array and add the invitation object at the end --
		if( size == 0 ){
			invitations = new CustDetail.Invitation[1];
			invitations[0]=invitation;
			resData.Invitations = invitations;
		} else {
			CustDetail.Invitation[] source = invitations;
			CustDetail.Invitation[] destination = new CustDetail.Invitation[size+1];
			System.arraycopy(source, 0, destination, 0, size);
			destination[size]=invitation;			
			resData.Invitations = destination;
		}		
		
	}
	
	/**
	 * This method adds an Elegibility Element for a customer and each
	 * related customer.  Elegibility is determined in the class
	 * ElectricOrangeEligibilityAssessment which is ran as a Thread for
	 * the customer and each related customer.
	 * 
	 * These threads are all managed by the ThreadsTimer class which collects and
	 * fires each thread, then sleeps until the threads have completed running or 
	 * time has expired. 
	 * 
	 * @param resultData - CustDetail processes so far.
	 * @param responseString - xml string containing the Detail Element
	 * @param requestOptions - Map of request parameters
	 * @param responseOptions - Map of response parameters
	 * @param cif - customer CIF
	 * @param lang - language 
	 * @param reqGwMsg - original requested GW message that is used to make additional requests
	 * @return
	 * @throws Exception
	 */ 
	public String processElectricOrange(CustDetail resultData, String responseString, Map requestOptions,  Map responseOptions, String cif, String lang, AutoMarshallGatewayMessage reqGwMsg)
	throws Exception
	{
		if(log.isLoggable(Level.FINEST) ) log.finest("000 - Started for CIF("+cif+").");
		
		final boolean validateXml = false;
		
		boolean ok;
		
		Document doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).newDocument();
		
		//-- Create the Element node by unmarshalling the response string --
		GatewayMessage gwMsgUnMarshall = new GatewayMessage();
		gwMsgUnMarshall.unmarshall(responseString, null, validateXml);
		Element gwDetailElement = gwMsgUnMarshall.cloneBodyForImport(doc);

		Map argsMap = new HashMap();
		argsMap.put(ARG_PRIMARY_ACCOUNT, gwDetailElement);
		argsMap.put(CustGetDetail.ARG_REQUEST_MAP, requestOptions);
		argsMap.put(CustGetDetail.ARG_RESPONSE_MAP, responseOptions);
		argsMap.put(CustGetDetail.ARG_RGW_MESSAGE, reqGwMsg);
		
		int nRelatedCustomers = 0;
		CustDetail.RelatedCustomer[] relatedCustomers = resultData.RelatedCustomer;
		if( relatedCustomers != null ){
		 nRelatedCustomers = relatedCustomers.length;
		}
		
		electricOrangeResults = new int[nRelatedCustomers+1];
		
		//Run Primary Electric Orange Assessment
		String id = "primary assessment for CIF("+cif+").";
		if(log.isLoggable(Level.FINEST) ) log.finest("030 - Firing "+ id);
		
		//-- Create a timer to manage the Threads 
		ThreadsTimer timer = new ThreadsTimer( EO_TIME_OUT_TO_WAIT, EO_TIME_TO_WAKE_UP, EO_TIME_OUT_COUNT, "Evaluating ALL EO - Primary CIF("+cif+").");
		timer.fire( new Thread ( new ElectricOrangeEligibilityAssessment(cif, lang, argsMap, 0), id) );

		argsMap = new HashMap();
		argsMap.put(CustGetDetail.ARG_REQUEST_MAP, requestOptions);
		argsMap.put(CustGetDetail.ARG_RESPONSE_MAP, responseOptions);
		argsMap.put(CustGetDetail.ARG_RGW_MESSAGE, reqGwMsg);
		
		//Run Electric Orange Assessment for each RelatedCustomer		
		String relatedCif;
		
		for(int i=0; i<nRelatedCustomers;i++){
			relatedCif = relatedCustomers[i].Cif._value;
			id="related customer assessment for CIF("+relatedCif+").";
			if(log.isLoggable(Level.FINEST) ) log.finest("050 - Firing "+id);
			//eoAssessment = new Thread (eoThreadGroup, new ElectricOrangeEligibilityAssessment(relatedCif, lang, argsMap, i+1) );
			//eoAssessment.start();
			timer.fire( new Thread ( new ElectricOrangeEligibilityAssessment(relatedCif, lang, argsMap, i+1) ) );
		}
		
		//-- Wait for all threads to complete --
		if(log.isLoggable(Level.FINEST) ) log.finest("060 - Waiting on all assessments for CIF("+cif+").");
		
		//-- Wait until all the Threads are done or time expires
		timer.sleep();
		timer.destroy();
		
		//-- If the timer expired, log warning but continue to process what we collected --
		if( timer.hasTimeExpired() ){
			log.warning("065-Time expired while processing cif("+cif+")");			
		}
		
		if(log.isLoggable(Level.FINEST) ) log.finest("070 - All assessments completed for CIF("+cif+").");
		
		/**
		 * Add Eligibility object to Primary
		 *   element 0 - is the Primary CIF
		 *   element 1-n - are the related CIF's
		 */ 
		if(log.isLoggable(Level.FINEST) ) log.finest("075 - Adding primary eligibility for CIF("+cif+").");
		ok = ( 1==electricOrangeResults[0] ); 
		resultData.Eligibility = addEligibility(resultData.Eligibility, TYPE_ELECTRIC_ORANGE, ok);

		//Add Eligibility object to each related customer
		for(int i=0; i<nRelatedCustomers;i++){
			if(log.isLoggable(Level.FINEST) ) log.finest("080 - Adding related customer eligibility for index("+i+").");
			ok = ( 1==electricOrangeResults[i+1] ); 
			relatedCustomers[i].Eligibility = addEligibility(relatedCustomers[i].Eligibility, TYPE_ELECTRIC_ORANGE, ok);			
		}		
		
		//Return the response string with the added Node(s)
		if(log.isLoggable(Level.FINEST) ) log.finest("090 - Marshalling the response to string.");
		
		AutoMarshallGatewayMessage gwMsg = new AutoMarshallGatewayMessage();
		gwMsg.initNew();
		gwMsg.setResponse();
		gwMsg.setResponseType(AutoMarshallGatewayMessage.RESTYPE_RESULT);
		gwMsg.setBodyData( resultData, "Detail" ); // Detail is the name of the body element tag
		String returnResponseString =  marshall(gwMsg, responseOptions);

		if(log.isLoggable(Level.FINEST) ) log.finest("999 - Done.");		
		return returnResponseString;
	}
	
	/**
	 * Adds an Eligibility object to the array
	 * 
	 * @param eligibility CustDetail array
	 * @param type - type of eligibility
	 * @param isEligible - boolean indicating eligibility
	 * @return expanded eligibility array
	 */ 
	private CustDetail.Eligibility[] addEligibility(CustDetail.Eligibility[] eligibility, String type, boolean isEligible){
		//Create the new entry
		CustDetail.Eligibility[] destination;
		CustDetail.Eligibility eligible = new CustDetail.Eligibility();
		eligible.EligibilityType = new SimpleElement(type);
		eligible.Eligible = new SimpleBooleanElement(isEligible);
		
		//-- Add the new entry to the array --
		int size = 0;
		if( eligibility != null){
			size = eligibility.length;
		}
		
		//-- Expand the array and add the eligibility object at the end --
		if( size == 0 ){
			destination = new CustDetail.Eligibility[1];
			destination[0]=eligible;
		} else {
			CustDetail.Eligibility[] source = eligibility;
			destination = new CustDetail.Eligibility[size+1];
			System.arraycopy(source, 0, destination, 0, size);
			destination[size]=eligible;
		}
		
		return destination;
	}

	/** 
	 * Simply obtaining data is idempotent.
	 */
	public boolean isIdempotent() {
		return true;
	}

	
	/**
	 * Call Back From ElectricOrangeEligibilityAssessment
	 * @param index  0 - Primary; 1-n Related Customer
	 * @param result 0 - false; 1-true
	 */ 
	 void onElectricOrangeEligibilityComplete(int index, int result, String comments){
		synchronized(EoEligibilityMutex) {
			
			if(log.isLoggable(Level.FINEST) ) {
				String id = " index("+index+") result("+result+") comments("+comments+") ";
				if(log.isLoggable(Level.FINEST) ) log.finest("000 - EO Completed STARTED/DONE============"+id+"=============");
			}
			
			electricOrangeResults[index]=result;			
		}		 
	}
	
	/**
	 * This class runs as a thread to determine whether a CIF is eligible for Electric Orange.
	 * It must first gather a CIF's detail, summaries and external links by running each in a 
	 * separate thread.  This information is then passed onto the ElectricOrangeEligibilityRule to
	 * determine the eligibility. Finally, a callback is made to communicate the result.
	 * 
	 * These threads are all managed by the ThreadsTimer class which collects and
	 * fires each thread, then sleeps until the threads have completed running or 
	 * time has expired. 
	 *   
	 */ 
	class ElectricOrangeEligibilityAssessment extends Thread implements IndexedObjectCallback {
		
		//-- index into the electricOrangeElements array --
		private final int INDEX_DETAILS = 0;
		private final int INDEX_SUMMARIES = 1;
		private final int INDEX_LINKS = 2;

		//-- --
		private Map argsMap;
		//-- CIF --
		private String cif;
		
		//-- Element array to hold the gathered data --
		private Element[] electricOrangeElements = new Element[3];
		
		//-- Object to manage synchronization in method onIndexedObjectComplete -- 
		private Object eoAssessmentMutex = new Byte((byte)0);
		
		//-- Index required for callback --
		private int index;
		
		//-- Language --
		private String lang;		
		
		/**
		 * Required Constructor
		 * 
 		 * @param cif - Customers CIF
		 * @param lang - language
		 * @param argsMap - additional arguments
		 * @param index - index which represents a position in an array for the CIF
		 */		
		ElectricOrangeEligibilityAssessment(String cif, String lang,  Map argsMap, int index){
			super();
			this.cif = cif;
			this.argsMap = argsMap;
			this.index = index;
			this.lang = lang;
		}
		
		/**
		 * Runnable Interface requirement
		 */ 
		public void run(){
			log.finest("000 - Started for CIF("+cif+").");
			
			String comments = "Assessment for Cif("+cif+").";
			boolean ok = false;
			try{
				//-- Process Electric Orange --
				int result = processElectricOrange() ? 1 : 0;
				
				//-- Post the result
				onElectricOrangeEligibilityComplete(index, result, comments);
				
				//-- Indicate we finished without exception --
				ok = true;
			} catch(Exception exception){
				log.severe("030 - Exception for : "+comments+"\n"+exception.toString());
			} finally {				
				if(! ok ){
					onElectricOrangeEligibilityComplete(index, 0, comments);					
				}
				
				log.finest("999 - Done for CIF("+cif+").");				
			}
		}
		
		/**
		 * Determines if CIF is eligible for Electric Orange by firing
		 * threads for Detail, Summaries and External Links data.
		 * Upon successful collection of data, the data is fed to a 
		 * rule to make the assessment.  Finally, a call back is made to
		 * communicate the assessment in the run method. 
		 * 
 		 * @return
		 * @throws Exception
		 */		
		public boolean processElectricOrange() throws Exception
		{
			log.finest("000 - Started for CIF("+cif+").");
			
			boolean ok;
			String id;	
			//
			AutoMarshallGatewayMessage reqGwMsg = ( AutoMarshallGatewayMessage ) argsMap.get( CustGetDetail.ARG_RGW_MESSAGE );
			
			//-- Create a timer to time the threads --
			ThreadsTimer timer = new ThreadsTimer( EO_TIME_OUT_TO_WAIT, EO_TIME_TO_WAKE_UP, EO_TIME_OUT_COUNT,
			                     "Evaluating EO for "+ (index == 0 ? "Primary" : "Related")+ " CIF("+cif+").");
			
			//Get the Detail
			if(index == 0){
				if(log.isLoggable(Level.FINEST) ) log.finest("010 - Primary Index.");				
			    electricOrangeElements[INDEX_DETAILS] = ( Element ) argsMap.get( ARG_PRIMARY_ACCOUNT );
			} else {
				id="Detail Thread for cif("+cif+").";
				if(log.isLoggable(Level.FINEST) ) log.finest("011 - Firing "+id);
				timer.fire(new Thread( new CustDetailRequestor(INDEX_DETAILS, this, cif, lang, reqGwMsg, argsMap), id ));
			}	

			//Get the Summaries
			id="Summaries Thread for cif("+cif+").";			
			if(log.isLoggable(Level.FINEST) ) log.finest("020 - Firing "+id);
			timer.fire(new Thread( new CustSummariesRequestor(INDEX_SUMMARIES, this, cif, reqGwMsg, argsMap), id ));
			
			//Get the Links
			id="Links Thread for cif("+cif+").";			
			if(log.isLoggable(Level.FINEST) ) log.finest("030 - Firing "+id);				
			timer.fire(new Thread( new CustExternalLinksRequestor(INDEX_LINKS, this, cif, reqGwMsg, argsMap), id ));
			
			//Wait for the Threads to complete
			if(log.isLoggable(Level.FINEST) ) log.finest("040 - Wait for data to be collected.");	
			timer.sleep();			
			timer.destroy();
			
			//-- If time expired then return false 
			if( timer.hasTimeExpired() ){
				log.warning("045-Done-Time expired while processing cif("+cif+")");
				return false;
			}
			
			if(log.isLoggable(Level.FINEST) ) log.finest("050 - All the data is collected.");	
			
			Element gwDetailElement = electricOrangeElements[INDEX_DETAILS];
			Element gwLinksElement = electricOrangeElements[INDEX_LINKS];
			Element gwSummariesElement = electricOrangeElements[INDEX_SUMMARIES];
			
			//-- If any of the elements are missing then return false --
			if( (gwDetailElement == null) || (gwLinksElement == null) || (gwSummariesElement == null) ){
				log.warning("055-Done-Null element(s) detected while processing cif("+cif+")");
				return false;				
			}
			
			if(log.isLoggable(Level.FINEST) ) log.finest("060 - Run the EO Assessment Rule for the data.");	
			
			NodeList gwLinksList = gwLinksElement.getElementsByTagName(RuleConstants.XML_EL_EXTERNAL_LINK);
			NodeList gwSummariesList = gwSummariesElement.getElementsByTagName(RuleConstants.XML_EL_SUMMARY);
		
			//-- Run the ElectricOrangeEligibilityRule --
			Map namedParamsMap = new HashMap();
			RuleEngineImpl ruleEngine = new RuleEngineImpl();
			Rule rule = new ElectricOrangeEligibilityRule();
		
			namedParamsMap.put( ElectricOrangeEligibilityRule.REQUIRED_FIRST_PARAMETER_CONTEXT_NODE, gwDetailElement );
			namedParamsMap.put( ElectricOrangeEligibilityRule.OPTIONAL_PARAMETER_LINKS, gwLinksList );
			namedParamsMap.put( ElectricOrangeEligibilityRule.OPTIONAL_PARAMETER_SUMMARIES, gwSummariesList );
			namedParamsMap.put( ElectricOrangeEligibilityRule.OPTIONAL_STANDARD_PARAMETER_COMMENTS,  "cif("+cif+")" );
		
			RuleResult result = ruleEngine.assess(rule, namedParamsMap, false);		
		
			ok = result.isOk();

			if(log.isLoggable(Level.FINEST) ) log.finest("999 - Done for CIF("+cif+") OK("+ok+").");			
			return ok;
		}
		
		/**
		 * Call back from Gathering Data on CIF
		 * 
		 * @param index   - representing one of Detail, Summary, External Links
		 * @param object  - Element
		 * @param comments - comments 
		 */ 
		public void onIndexedObjectComplete(int index, Object object, String comments){
		   synchronized(eoAssessmentMutex) {
			   if(log.isLoggable(Level.FINEST) ){
			    String id = " index("+index+") comments("+comments+") ";			
			    log.finest(" ============ Data for indexed Object gathered."+id+"=============");
			   }
			   
			   electricOrangeElements[index]=(Element) object;
		   }
		}
				
	} // ~
	
}// ~