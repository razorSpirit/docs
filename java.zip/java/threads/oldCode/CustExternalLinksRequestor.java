package com.ingdirect.dg.util;

//Standard Java
import java.util.Map;
import java.util.HashMap;
import java.util.logging.Logger;
import java.util.logging.Level;
//   Third Party
import org.w3c.dom.Document;
import org.w3c.dom.Element;
//   ING DIRECT
import com.ingdirect.dg.xmlbind.AutoMarshallGatewayMessage;
import com.ingdirect.dg.xmlbind.GatewayMessage;
import com.ingdirect.dg.xmlbind.XMLBindException;
import com.ingdirect.dg.xmlbind.data.CustId;
import com.ingdirect.dg.service.AccountGetLinks;
import com.ingdirect.dg.service.CustGetDetail;
import com.ingdirect.util.xml.ThreadLocalDocumentBuilder;
import com.ingdirect.util.xml.SimpleElement;
import com.ingdirect.util.log.PerfLog2;
import com.ingdirect.util.threading.IndexedObjectCallback;
import com.ingdirect.util.StringUtil;

/**
 * This class is a Thread which issues a request to the direct gateway
 * to retrieve the External Links for a customer .  Upon completion of the thread,
 * a call back is issued to post the result.
 * 
 * @see CustGetDetail
 * 
 * @author abrida
 * @version $Revision: 409 $
 */
public class CustExternalLinksRequestor extends Thread {
	//-- Map passed which contains the CustGetDetail.ARG_REQUEST_MAP and CustGetDetail.ARG_RESPONSE_MAP --
	private Map argsMap;
	
	//-- IndexObject caller that called this thread --
	private IndexedObjectCallback caller;
	
	//-- The name of the class and the name used by the logger. --
	private final String CLASS_ID = CustExternalLinksRequestor.class.getName();
	private final String logName = CLASS_ID;
	
	//-- Customer's CIF to be processed --
	private String cif;
	
	//-- index ID where callback is to place the results --
	private int indexId;

	//-- standard log --
	private Logger log = Logger.getLogger(logName);
	
	//-- performance log --
	private static PerfLog2 perfLog = new PerfLog2();	
	
	//-- Passed request gateway message needed to create additional requests -- 
	private AutoMarshallGatewayMessage reqGwMsg;
		
	/**
	 * Required constructor
	 * 
 	 * @param indexId - index ID required for IndexedObjectCallback to post results
	 * @param caller  - IndexedObjectCallback caller
	 * @param cif     - customers CIF
	 * @param reqGwMsg - request Gateway Message to create additional GW messages 
	 * @param argsMap  - additional arguments
	 * 
	 * @see IndexedObjectCallback
	 * @see CustGetDetail
	 * 
	 */		
	public CustExternalLinksRequestor(int indexId, IndexedObjectCallback caller, String cif, AutoMarshallGatewayMessage reqGwMsg, Map argsMap)
	{
		super();
		this.caller = caller;
		this.indexId = indexId;
		this.cif = cif;
		this.reqGwMsg = reqGwMsg;
		this.argsMap = argsMap;
	}

	/**
	 * Required method for Runnable interface.
	 */ 
	public void run() {
		Element element = null;
		Map requestOptions = (Map) argsMap.get( CustGetDetail.ARG_REQUEST_MAP );
		Map responseOptions = (Map) argsMap.get( CustGetDetail.ARG_RESPONSE_MAP );
		
		if( requestOptions == null){
			requestOptions = new HashMap();
		}
		if( responseOptions == null){
			responseOptions = new HashMap();
		}		
		
		try{
			element = getLinksByCif(requestOptions, responseOptions);
		} catch(Exception exception){
			log.severe("Exception for cif("+cif+")\n"+exception.toString());
		}
		
		if( caller != null){
			caller.onIndexedObjectComplete(indexId, element, CLASS_ID);
		}
		
	}
	
	/**
	 * This method issues a request to obtain a customers external links
	 * 
	 * @param requestOptions - Map containing request options
	 * @param responseOptions - Map containing containing response options
	 * @return Element representing the customers external links
	 * @throws Exception
	 */ 
	Element getLinksByCif(Map requestOptions, Map responseOptions)	throws Exception {
	
		final String DG_TRAN_LINKS = "AccountGetLinks";
		boolean validateXml = false;
		String dgResponse = null;
		
		//Create a request for the Links
		CustId custId = new CustId();		
		custId.CIF= new SimpleElement(cif);

		AutoMarshallGatewayMessage dgReq = new AutoMarshallGatewayMessage();
		dgReq.initNew();
		dgReq.cloneIdentities(reqGwMsg);
		dgReq.setTransaction(DG_TRAN_LINKS);
		dgReq.setBodyData( custId, "Id");
		
		//Convert the request to an XML string
		String dgReqXml = dgReq.marshallToString();
		
		if( log.isLoggable(Level.FINEST) ) log.finest("Request for cif("+cif+"):\n"+StringUtil.fillNull(dgReqXml));
		
		//Make the request for the transaction
		AccountGetLinks getDgResponse = new AccountGetLinks();
		
		try{	
			perfLog.startDgInvoke(DG_TRAN_LINKS);
			dgResponse = getDgResponse.execute(DG_TRAN_LINKS, dgReqXml, requestOptions, responseOptions );
			perfLog.stop(true); 
		} catch(Exception exception){
			throw exception;
		} finally {
			perfLog.stop(true);			
		}
		
		if( log.isLoggable(Level.FINEST) ) log.finest("Response for cif("+cif+"):\n"+StringUtil.fillNull(dgResponse));
		
		//-- Get the the External Links Element --
		Document doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).newDocument();
		GatewayMessage gwMsgUnMarshall = new GatewayMessage();
		gwMsgUnMarshall.unmarshall(dgResponse, null, validateXml);
		Element element = gwMsgUnMarshall.cloneBodyForImport(doc);
				
		// done
		return element;
	}	

	public static Object invokeAsync(String cif, AutoMarshallGatewayMessage reqGwMsg, Map argsMap){
		
		return new Object();
	}
	public static Element unmarshallResponse(String dgResponse, boolean validateXml)
		throws XMLBindException
	{
		
		Document doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).newDocument();
		GatewayMessage gwMsgUnMarshall = new GatewayMessage();
		gwMsgUnMarshall.unmarshall(dgResponse, null, validateXml);
		Element element = gwMsgUnMarshall.cloneBodyForImport(doc);
		return element;
	}
		
} //~