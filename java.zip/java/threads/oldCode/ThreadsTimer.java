package com.ingdirect.util.threading;

//Standard Java
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
//   Third Party

//   ING DIRECT

/**
 * This class is used to block a caller until all the threads
 * have completely ran or the amount of time to wait has expired.
 * 
 * @author abrida
 * @version $Revision: 409 $
 */
public class ThreadsTimer {
	/**
	 * The ClassId for this Class
	 */ 
	private final static String CLASS_ID = ThreadsTimer.class.getName();
	/**
	 * The logName given to the logger
	 */ 
	private final static String LOG_NAME = CLASS_ID;
	/**
	 * The logger
	 */ 
	private final static Logger log = Logger.getLogger(LOG_NAME);
	
	/**
	 * The type of events to send in the callback. 
	 */ 
	public static final int EVENT_CHECK_CONDITION = 0;
	public static final int EVENT_TIMED_OUT = 1;
	
	/**
	 * The amount of time (millis) to wait for a timeout.
	 */ 
	private long timeOutToWait=0;
	
	/**
	 * The amount of time to wake up to check to
	 * see if the condition is true.  In other words,
	 * how often to wake up to check the condition.
	 * 
	 *  timeToWakeInterval is alway less then timeOutToWait
	 */ 
	private long timeToWakeInterval=0;
	
	/**
	 * The number of timeouts allowed.
	 */ 
	private int timeOutCount =1;
	
	/**
	 * Running count of how many times we timed out.
	 */ 
	private int timeOutCounter;	

	/**
	 * Running counter of number of times we woke up.
	 * The total number of times we can wake up before incrementing the
	 * timeOutCounter is found in the timeIntervalToWaitCount.
	 * @see timeIntervalToWaitCount
	 */ 
	private int timeIntervalCounter = 0;
	
	/**
	 * Map for managing the Threads.
	 */ 
	private Map threadsMap = new HashMap();
	
	/**
	 * The total number of intervals to wait.  You may also think of 
	 * this is as the total number of wake ups. This number is calculated
	 * in the following way : (timeOutToWait / timeToWakeInterval) + 1.
	 * 
	 * @see timeIntervalCounter
	 * @see timeOutToWait
	 * @see timeToWakeInterval
	 */	
	private int timeIntervalToWaitCount = 0;
	
	/**
	 * Any comments to pass to the caller to identify the kind 
	 * of conditions we are waiting on.
	 */ 
	private String comments;
	
	/**
	 * Flag that indicates wheter all the threads
	 * ran to completion before the alotted time.
	 */ 
	private boolean hasTimeExpired = false;
	
	/**
	 * Required Constructor.
	 * 
	 * @param timeOutToWait - time to wait in millis for a timeout 
	 * @param timeToWakeInterval - time to wait before waking up
	 * @param timeOutCount - the number of timeouts 
	 * @param comments - comments 
	 */	
	public ThreadsTimer( long timeOutToWait, long timeToWakeInterval, int timeOutCount, String comments ){
		super();
		this.timeOutToWait = timeOutToWait;
		this.timeToWakeInterval = timeToWakeInterval;
		this.timeOutCount = (timeOutCount <= 0 ? 1 : timeOutCount);
		this.comments = comments;
		
		timeIntervalToWaitCount = new Long( (timeOutToWait / timeToWakeInterval) ).intValue() + 1;
		if(log.isLoggable(Level.FINEST) ) log.finest("ThreadsTimer created for "+comments);
	}
	
	/**
	 * Flag. 
	 * @return true if all the threads did not run to completion before the alotted time.
	 */ 
	public boolean hasTimeExpired() { return hasTimeExpired; }

	/**
	 * Getter and Setter for timeOutToWait	 
	 *  
	 * @return
	 * @see timeOutToWait
	 */ 
	public long getTimeOutToWait() { return timeOutToWait; }
	public void setTimeOutToWait(long timeOutToWait) { this.timeOutToWait=timeOutToWait; }

	/**
	 * Getter and Setter for timeToWakeInterval
	 *  
	 * @return
	 * @see timeToWakeInterval
	 */ 
	public long getTimeToWakeInterval() { return timeToWakeInterval; }
	public void setTimeToWakeInterval(long timeToWakeInterval) { this.timeToWakeInterval=timeToWakeInterval; }
	
	/**
	 * Getter and Setter for timeOutCount
	 *  
	 * @return
	 * @see timeOutCount
	 */ 
	public int getTimeOutCount() { return timeOutCount; }
	public void setTimeOutCount(int timeOutCount) { this.timeOutCount=timeOutCount; }
	
	/**
	 * Getter and Setter for timeIntervalCounter
	 *  
	 * @return
	 * @see timeIntervalCounter
	 */ 
	public int getTimeIntervalCounter() { return timeIntervalCounter; }
	public int getTimeOutCounter() { return timeOutCounter; }
	
	/**
	 * Getter and Setter for comments
	 *  
	 * @return
	 * @see timeOutCount
	 */ 
	public String getComments() { return comments; }
	public void setComments(String comments) { this.comments=comments; }

	/**
	 * Method to add a thread to the threadsMap and to start the thread.
	 * 
 	 * @param thread - Thread to be started and added to the threadsMap.
	 */		
	public void fire(Thread thread){
		thread.start();
		threadsMap.put("thread"+threadsMap.size(), thread);
	}
	
	/**
	 * Method to destroy any outstanding Threads and
	 * to remove all the thread entries from the threadsMap.
	 */ 
	public void destroy(){
		if(threadsMap.isEmpty() ){
			return;
		}
		String key;
		Thread thread;
		Map threadsCopy = new HashMap();
		threadsCopy.putAll(threadsMap);
		
		for(Iterator it=threadsCopy.keySet().iterator();it.hasNext();){
			key=(String) it.next();
			thread=(Thread) threadsCopy.get(key);
			
			if( (thread != null) && (thread.isAlive()) ) {
				thread.destroy();
			}
			
			threadsMap.remove(key);
		}		
	}
	
	/**
	 * Method that waits until all the threads in the threadsMap to have completely
	 * ran or the number of timeouts to have been exceeded.
	 */ 
	public void sleep() {
		boolean ok = false;
		hasTimeExpired = false;		
		
		log.finest("000-Sleep invoked for "+comments);
		
		//-- loop for the number of timeouts permitted --
		for(timeOutCounter=0; timeOutCounter<timeOutCount; timeOutCounter++){
			if(log.isLoggable(Level.FINEST) ) log.finest(comments+" Timeout counter at "+timeOutCounter+" of "+timeOutCount);
			
			//-- loop for the calculated number of intervals to wake for a given timeout
			for(timeIntervalCounter = 0; timeIntervalCounter < timeIntervalToWaitCount ; ++timeIntervalCounter){
				
				try{ Thread.sleep( timeToWakeInterval ); }
				catch(Exception exception){
					log.warning("010-Exception for "+getComments()+" \n"+exception.toString());
				}
				if(log.isLoggable(Level.FINEST) ) log.finest("020- Wakeup "+getComments()+" at count "+timeIntervalCounter+" of "+timeIntervalToWaitCount);
				
				String key;
				Thread thread;
				ok = true;
				
				//-- if there are any threads alive then we are NOT done --
				for(Iterator it=threadsMap.keySet().iterator();it.hasNext();){
					key=(String) it.next();
					thread=(Thread) threadsMap.get(key);
			
					if( (thread != null) && (thread.isAlive()) ) {
						ok=false;
						break;
					}
				}		
					
				if(ok){
					break;						
				}
				
			} // inner for
			
			//If the condition was completed then we are done
			if(log.isLoggable(Level.FINEST) ) log.finest("060-"+comments+" broke out of sleep loop ok("+ok+")");
			if(ok){
				break;
			}
			
		} // outter for
		
		hasTimeExpired = ! ok;
		
		//-- Done --
		if(log.isLoggable(Level.FINEST) ) log.finest("999A-"+comments+" Done ok("+ok+") hasTimeExpired("+hasTimeExpired+")");
	}
	
} //~