package com.ingdirect.dg.util;

//Standard Java
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import java.util.logging.Level;
//   Third Party
import org.w3c.dom.Document;
import org.w3c.dom.Element;
//   ING DIRECT
import com.ingdirect.dg.xmlbind.AutoMarshallGatewayMessage;
import com.ingdirect.dg.xmlbind.GatewayMessage;
import com.ingdirect.dg.xmlbind.CustSearch;
import com.ingdirect.dg.xmlbind.XMLBindException;
import com.ingdirect.dg.service.CustGetSummary;
import com.ingdirect.dg.service.CustGetDetail;
import com.ingdirect.util.xml.ThreadLocalDocumentBuilder;
import com.ingdirect.util.ApplicationProperties;
import com.ingdirect.util.StringUtil;
import com.ingdirect.util.threading.IndexedObjectCallback;
import com.ingdirect.util.log.PerfLog2;

/**
 * This class is a Thread which issues a request to the direct gateway
 * to retrieve the summaries data for the customer.  Upon completion of the thread,
 * a call back is issued to post the result.
 * 
 * @see CustGetDetail
 * 
 * @author abrida
 * @version $Revision: 409 $
 */
public class CustSummariesRequestor extends Thread{
	//-- Map passed which contains the CustGetDetail.ARG_REQUEST_MAP and CustGetDetail.ARG_RESPONSE_MAP --
	private Map argsMap;
	
	//-- IndexObject caller that called this thread --
	private IndexedObjectCallback caller;

	//-- The name of the class and the name used by the logger. --
	private final String CLASS_ID = CustSummariesRequestor.class.getName();
	private final String logName = CLASS_ID;
	
	//-- Customer's CIF to be processed --
	private String cif;	
	
	//-- index ID where callback is to place the results --
	private int indexId;

	//-- standard log --
	private Logger log = Logger.getLogger(logName);
	
	//-- performance log --
	private static PerfLog2 perfLog = new PerfLog2();
	
	//-- Passed request gateway message needed to create additional requests -- 
	private AutoMarshallGatewayMessage reqGwMsg;
		
	/**
	 * Required constructor
	 * 
 	 * @param indexId - index ID required for IndexedObjectCallback to post results
	 * @param caller  - IndexedObjectCallback caller
	 * @param cif     - customers CIF
	 * @param reqGwMsg - request Gateway Message to create additional GW messages 
	 * @param argsMap  - additional arguments
	 * 
	 * @see IndexedObjectCallback
	 * @see CustGetDetail
	 * 
	 */		
	public CustSummariesRequestor(int indexId, IndexedObjectCallback caller, String cif, AutoMarshallGatewayMessage reqGwMsg, Map argsMap){
		super();
		this.cif = cif;
		this.reqGwMsg = reqGwMsg;
		this.caller = caller;
		this.indexId = indexId;
		this.argsMap = argsMap;
	}
	
	/**
	 * Required method for Runnable interface.
	 */ 
	public void run() {
		Element element = null;
		Map requestOptions = (Map) argsMap.get( CustGetDetail.ARG_REQUEST_MAP );
		Map responseOptions = (Map) argsMap.get( CustGetDetail.ARG_RESPONSE_MAP );
		
		if( requestOptions == null){
			requestOptions = new HashMap();
		}
		if( responseOptions == null){
			responseOptions = new HashMap();
		}		
		
		try{
			element = getSummariesByCif(requestOptions, responseOptions);
		} catch(Exception exception){
			log.severe("Exception : "+exception.toString());
		}
		
		if( caller != null){
			caller.onIndexedObjectComplete(indexId, element, CLASS_ID);
		}
	}
	
	/**
	 * This method issues a request to obtain a customers summary information
	 * 
	 * @param requestOptions - Map containing request options
	 * @param responseOptions - Map containing containing response options
	 * @return Element representing the customers summary information
	 * @throws Exception
	 */ 
	Element getSummariesByCif(Map requestOptions, Map responseOptions)	throws Exception {
		final String DG_TRAN_SEARCH = "CustFind";
		final String CFG_MAXRECORDS = "cmd.lookup.maxRecords";
		final String DFT_MAXRECORDS = "30";
		boolean validateXml = false;
		String dgResponse = null;
		
		//TODO ajb : DON'T I want all the summaries ?
		int maxRecords = Integer.parseInt(
				ApplicationProperties.getProperty(CFG_MAXRECORDS, DFT_MAXRECORDS));
		
		//-- Create the request --
		CustSearch dgReq = new CustSearch();
		
		dgReq.initNew();
		dgReq.cloneIdentities(reqGwMsg);
		dgReq.setTransaction(DG_TRAN_SEARCH);

		dgReq.setMaxRecords(maxRecords);
		dgReq.setUserId(cif);  
		dgReq.setTelephone(null);
		dgReq.setLastName(null);
		dgReq.setFirstName(null);
		dgReq.setPostcode(null);
		dgReq.setExternalId(null);
		dgReq.setEmail(null);
		dgReq.setSolicitId(null);
		dgReq.setDateOfBirth(null);

		String dgReqXml = dgReq.marshallToString();

		if( log.isLoggable(Level.FINEST) ) log.finest("Request for cif("+cif+"):\n"+StringUtil.fillNull(dgReqXml));
		
		//-- prepare the response --		
		CustGetSummary getDgResponse = new CustGetSummary();

		//-- issue the request --		
		try{	
			perfLog.startDgInvoke(DG_TRAN_SEARCH);
			dgResponse = getDgResponse.execute(DG_TRAN_SEARCH, dgReqXml, requestOptions, responseOptions );
			perfLog.stop(true); 
		} catch(Exception exception){
			throw exception;
		} finally {
			perfLog.stop(true);			
		}

		if( log.isLoggable(Level.FINEST) ) log.finest("Response for cif("+cif+"):\n"+StringUtil.fillNull(dgResponse));
		
		//-- UnMarshall the result --
		Document doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).newDocument();
		GatewayMessage gwMsgUnMarshall = new GatewayMessage();
		gwMsgUnMarshall.unmarshall(dgResponse, null, validateXml);
		
		//TODO ajb : Response could be an Error ???
		Element element  = gwMsgUnMarshall.cloneBodyForImport(doc);
				
		//-- Done --		
		return element;
	}

	public static Object invokeAsync(String cif, AutoMarshallGatewayMessage reqGwMsg, Map argsMap){
		
		return new Object();
	}
	
	public static Element unmarshallResponse(String dgResponse, boolean validateXml)
		throws XMLBindException
	{
		
		Document doc = ThreadLocalDocumentBuilder.getDocumentBuilder(false).newDocument();
		GatewayMessage gwMsgUnMarshall = new GatewayMessage();
		gwMsgUnMarshall.unmarshall(dgResponse, null, validateXml);
		Element element = gwMsgUnMarshall.cloneBodyForImport(doc);
		return element;
	}
	
} //~
