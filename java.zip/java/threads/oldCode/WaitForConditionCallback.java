package com.ingdirect.util.threading;

/**
 * @version $Revision: 409 $
 */
public interface WaitForConditionCallback {
	public boolean onWakeUpForCondition(int conditionId, int eventId, String comments, int counter);
}
