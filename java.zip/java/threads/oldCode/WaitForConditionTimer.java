package com.ingdirect.util.threading;

//Standard Java
import java.util.logging.Logger;
import java.util.logging.Level;
//   Third Party

//   ING DIRECT

/**
 * This class is used to block a caller until a condition defined
 * by the WaitForConditionCallback caller is found to be true.
 * 
 * @author abrida
 * @version $Revision: 409 $
 */

public class WaitForConditionTimer {
	/**
	 * The ClassId for this Class
	 */ 
	private final static String CLASS_ID = WaitForConditionTimer.class.getName();
	/**
	 * The logName given to the logger
	 */ 
	private final static String LOG_NAME = CLASS_ID;
	/**
	 * The logger
	 */ 
	private final static Logger log = Logger.getLogger(LOG_NAME);
	
	/**
	 * The type of events to send in the callback. 
	 */ 
	public static final int EVENT_CHECK_CONDITION = 0;
	public static final int EVENT_TIMED_OUT = 1;
	
	/**
	 * The total time to wait in milliseconds.
	 */ 
	private long timeToWait=0;
	
	/**
	 * The amount of time to wake up to check to
	 * see if the condition is true.  In other words,
	 * how often to wake up to check the condition.
	 * 
	 *  timeToWakeInterval is alway less then timeToWait
	 */ 
	private long timeToWakeInterval=0;
	
	/**
	 * The number of times to retry after we have cycled through
	 * the timeIntervalToWaitCount. 
	 */ 
	private int timeOutCount =0;
	
	/**
	 * Running count of how many times we cycled through
	 * the timeIntervalToWaitCount.
	 */ 
	private int timeOutCounter;	

	/**
	 * Running counter of number of times we woke up
	 * to check for a true condition.  The total number
	 * of times we can wake up before incrementing the
	 * timeOutCounter is found in the timeIntervalToWaitCount.
	 * @see timeIntervalToWaitCount
	 */ 
	private int timeIntervalCounter = 0;
	
	/**
	 * The total number of intervals to wait.  You may also think of 
	 * this is as the total number of wake ups. This number is calculated
	 * in the following way : (timeToWait / timeToWakeInterval) + 1.
	 * 
	 * @see timeIntervalCounter
	 * @see timeToWait
	 * @see timeToWakeInterval
	 */	
	private int timeIntervalToWaitCount = 0;
	
	/**
	 * The caller to interrogate the condition to stop blocking.
	 */ 
	private WaitForConditionCallback caller;
	
	/**
	 * An ID given to this timer, so that we can evaluate a 
	 * specific condition in the WaitForConditionCallback caller.
	 * This is needed if there are more then 1 timers created.
	 */ 
	private int conditionId = 0;
	
	/**
	 * Any comments to pass to the caller to identify the kind 
	 * of conditions we are waiting on.
	 */ 
	private String comments;
	
	/**
	 * Flag that indicates that we have timed out and
	 * that the condition we are interrogating has never
	 * been set to true.
	 */ 
	private boolean isTimedOut = false;
	
	/**
	 * 
 	 * @param caller
	 * @param conditionId
	 * @param timeToWait
	 * @param timeToWakeInterval
	 * @param timeOutCount
	 * @param comments
	 */	
	public WaitForConditionTimer(WaitForConditionCallback caller, int conditionId, long timeToWait, long timeToWakeInterval, int timeOutCount, String comments){
		super();
		this.caller = caller;
		this.conditionId = conditionId;
		this.timeToWait = timeToWait;
		this.timeToWakeInterval = timeToWakeInterval;
		this.timeOutCount = timeOutCount;
		this.comments = comments;
		
		timeIntervalToWaitCount = new Long( (timeToWait / timeToWakeInterval) ).intValue() + 1;
		if(log.isLoggable(Level.FINEST) ) log.finest("Created for "+comments);
	}
	
	/**
	 * Flag. 
	 * @return true if the condition we are interogating was never found to be true.
	 */ 
	public boolean isTimedOut() { return isTimedOut; }

	public int getTimeOutCount() { return timeOutCount; }
	public void setTimeOutCount(int timeOutCount) { this.timeOutCount=timeOutCount; }

	public int getTimeIntervalCounter() { return timeIntervalCounter; }
	public int getTimeOutCounter() { return timeOutCounter; }
	
	public String getComments() { return comments; }
	public void setComments(String comments) { this.comments=comments; }

	/**
	 * 
	 */ 
	public void sleep() {
		boolean ok = false;
		isTimedOut = false;		
		
		log.finest("000-Sleep invoked for "+comments);
		
		for(timeOutCounter=0; timeOutCounter<timeOutCount; timeOutCounter++){
			if(log.isLoggable(Level.FINEST) ) log.finest(comments+" Timeout counter at "+timeOutCounter+" of "+timeOutCount);
			
			for(timeIntervalCounter = 0; timeIntervalCounter < timeIntervalToWaitCount ; ++timeIntervalCounter){
				
				try{ Thread.sleep( timeToWakeInterval ); }
				catch(Exception exception){
					;
				}
				if(log.isLoggable(Level.FINEST) ) log.finest("020- Wakeup "+getComments()+" at count "+timeIntervalCounter+" of "+timeIntervalToWaitCount);
				
				if(caller == null){
					if(log.isLoggable(Level.FINEST) ) log.finest("030- Wakeup "+getComments()+" at count "+timeIntervalCounter+" of "+timeIntervalToWaitCount+" CALLER IS NULL.");
					ok=true;
				} else {
					ok = caller.onWakeUpForCondition(conditionId, EVENT_CHECK_CONDITION, getComments(), timeIntervalCounter);
				}
					
				if(ok){
					break;						
				}
				
			} // inner for
			
			//If the condition was completed then we are done
			if(log.isLoggable(Level.FINEST) ) log.finest("060-"+comments+" broke out of sleep loop ok("+ok+")");
			if(ok){
				break;
			}
			
		} // outter for
		
		isTimedOut = ! ok;
		
		//If the condition was completed then we timed out
		if(log.isLoggable(Level.FINEST) ) log.finest("999A-"+comments+" Done ok("+ok+") hasTimeExpired("+isTimedOut+")");
		if( ok ){
			if(log.isLoggable(Level.FINEST) ) log.finest("**** COMPLETED **** "+comments);			
		} else {
			caller.onWakeUpForCondition(conditionId, EVENT_TIMED_OUT, comments, timeIntervalCounter);
		}
	}
	
} //~
