REM
REM $Header: cat_pop.sql 05-mar-2001.15:50:52 jgallus Exp $  
REM
REM Copyright (c) 2005 Oracle Corporation.  All rights reserved.
REM
REM Owner  : ahunold
REM
REM NAME
REM   cat_pop.sql - OC (Online Catalog) of OE Common Schema
REM
REM DESCRIPTON
REM   Populates CATORGIES tables
REM

SPOOL popCat.out



INSERT INTO abrida.oe_categories
  VALUES ('hardware1', 'monitors', 11) ;


INSERT INTO abrida.oe_categories
  VALUES ('hardware2', 'printers', 12) ;


INSERT INTO abrida.oe_categories
  VALUES ('hardware3', 'harddisks', 13) ;


INSERT INTO abrida.oe_categories
  VALUES ('hardware4', 'memory components/upgrades', 14) ;


INSERT INTO abrida.oe_categories
  VALUES ('software4', 'operating systems', 24) ;


INSERT INTO abrida.oe_categories
  VALUES ('hardware5'
         , 'processors, sound and video cards, network cards, motherboards', 15) ;


INSERT INTO abrida.oe_categories
  VALUES ('hardware6', 'keyboards, mouses, mouse pads', 16) ;


INSERT INTO abrida.oe_categories
  VALUES ('hardware7'
         , 'other peripherals (CD-ROM, DVD, tape cartridge drives, ...)', 17) ;


INSERT INTO abrida.oe_categories
  VALUES ('hardware8'
         , 'miscellaneous hardware (cables, screws, power supplies ...)', 19) ;

INSERT INTO abrida.oe_categories
  VALUES ('software1', 'spreadsheet software', 21) ;


INSERT INTO abrida.oe_categories
  VALUES ('software2', 'word processing software', 22) ;


INSERT INTO abrida.oe_categories
  VALUES ('software3', 'database software', 23) ;


INSERT INTO abrida.oe_categories
  VALUES ('software5', 'software development tools (including languages)', 25) ;


INSERT INTO abrida.oe_categories
  VALUES ('software6', 'miscellaneous software', 29) ;


INSERT INTO abrida.oe_categories
  VALUES ('office1', 'capitalizable assets (desks, chairs, phones ...)', 31) ;


INSERT INTO abrida.oe_categories
  VALUES ('office2'
         , 'office supplies for daily use (pencils, erasers, staples, ...)', 32) ;


INSERT INTO abrida.oe_categories
  VALUES ('office3', 'manuals, other books', 33) ;


INSERT INTO abrida.oe_categories
  VALUES ('office4', 'miscellaneous office supplies', 39) ;


INSERT INTO abrida.oe_categories
  VALUES ('hardware', 'computer hardware and peripherals', 10) ;


INSERT INTO abrida.oe_categories
  VALUES ('software', 'computer software', 20) ;


INSERT INTO abrida.oe_categories
  VALUES ('office equipment', 'office furniture and supplies', 30) ;


INSERT INTO abrida.oe_categories
  VALUES ('online catalog'
         , 'catalog of computer hardware, software, and office equipment'
         , 90) ;

REM commit;

SPOOL OFF;

exit;

