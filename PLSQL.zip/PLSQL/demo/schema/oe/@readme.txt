ref: http://st-curriculum.oracle.com/obe/jdev/obe11jdev/11/common/connection11g.htm#t1

Please run the scripts one at a time sql plus
after copying them to /oracle/abrida/oe on c drive
    --- OR ---
run the abrida_oe_main.sql


SQL>@/oracle/abrida/oe/abrida_oe_p_pi.sql
SQL>commit
SQL>/