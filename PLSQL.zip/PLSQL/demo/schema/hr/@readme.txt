ref: http://st-curriculum.oracle.com/obe/jdev/obe11jdev/11/common/connection11g.htm#t1

Please run the scripts one at a time sql plus
after copying them to /oracle/abrida/hr on c drive
    --- OR ---
run the abrida_hr_main.sql


SQL>@/oracle/abrida/hr/abrida_hr_popul.sql
SQL>commit
SQL>/