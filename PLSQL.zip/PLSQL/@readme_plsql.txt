C:\Oracle\Ora10R2\BIN\sqlplusw.exe

Execute
  SQL> /
  
Current directory
  Issue host to take you to command prompt for current directory 
  SQL>host
  
Running a script
  SQL>@{file}
  SQL>@{path}{file}
  
  assumes you are in current directory (where you launched sql plus)
  SQL>@/oracle/tony/myfile.sql
 
SQL*PLUS
  SQL>DECLARE
  SQL>EDIT 
 
  Will cause notepad to show, where you can enter the rest of 
  the script.
  
  try the following:    
   
DECLARE
  e_show_exception_scope EXCEPTION;
  v_student_id NUMBER := 123;
BEGIN
  DBMS_OUTPUT.PUT_LINE('outer id is ' || v_student_id);
  DECLARE
    v_student_id NUMBER := 999;
   BEGIN
    DBMS_OUTPUT.PUT_LINE('inner id is ' || v_student_id);
    raise e_show_exception_scope;
   END;
EXCEPTION
  WHEN e_show_exception_scope
  THEN
    DBMS_OUTPUT.PUT_LINE('From exception. id is ' || v_student_id);
END;
/  

  To run the script:
  SQL>set serveroutput on
  SQL>/
  
  You won't see any output unless you issue: set serveroutput on
  
  
   
