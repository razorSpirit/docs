This lib was downloaded from :

http://xsltsl.sourceforge.net/string.html