Lesson 003 : Axes
Reference  : p. 79

