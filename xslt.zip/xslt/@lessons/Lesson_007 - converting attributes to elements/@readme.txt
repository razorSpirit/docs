Lesson 007 : Converting attributes to elements
Reference  : p. 122

