Lesson 014 : look-up table
Reference  : p. 282

