Lesson 001 : Node value vs Element value
Reference  : p. 46,47

pets1 yields a Node value, which is the concatenation of the text
value of the element and the concatenation of all it's child element
text values.

pets2 yields the text value of the element, which is the text value
of the current element.