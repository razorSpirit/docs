Lesson 013 :  function template returning exsl.node-set
Reference  : p. 236

