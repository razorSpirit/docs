Lesson 009 :  attribute-set
Reference  : p. 127

From www.xml.com :

Problem :
You want to generate HTML that is styled based on data content. 

Solution
XSLT attribute sets provide a nice vehicle for encapsulating the complexity of 
data-driven stylization. Consider how XML describes an investment portfolio: 
portfolio.xml.

You should display this portfolio in a table with a column showing the 
gain in black or the loss in red: listPortfolio.xsl.

