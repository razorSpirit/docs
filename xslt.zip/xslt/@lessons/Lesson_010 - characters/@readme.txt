Lesson 010 :  characters
Reference  : p. 179

From www.xml.com :

