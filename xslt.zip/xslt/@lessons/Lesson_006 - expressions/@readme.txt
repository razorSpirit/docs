Lesson 006 : Expressions
Reference  : p. 119,120 155

try the following using 06list01.xml with O2 XPath builder:

/employees/employee[position()=1]/child::phonenumber[attribute::type = 'home']



