Lesson 002 : tree fragment vs node set
Reference  : p. 62,63 and 68,69

pets1 on line 5 is a selection of a tree fragment, which is a part of an xml tree.
The value of a tree fragment is the text value of the root element and
the concatenation of all it's child elements.

pets2 on line 5 is a selection of a node-set.  The node-set consists of
three nodes : Max, Peter and Rocky.

A tree fragment IS A hierarchy of nodes - A nodes set IS NOT.

The value of a node set consists of the text value of the first node only.
In this example, only Max will be printed.

pet3 on line 5 applies the template match="pets/pet" which is a node-set.
This template then applies the appropiate template to each of the child 
nodes. **NOTE that templates pet[1] and pet[2] are defined but pet[3] is 
not defined, so the default template is used.

pet4 on line 9 loops through the pet node-set by position.