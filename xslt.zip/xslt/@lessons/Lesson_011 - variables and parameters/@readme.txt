Lesson 011 :  variables and parameters
Reference  : p. 208

