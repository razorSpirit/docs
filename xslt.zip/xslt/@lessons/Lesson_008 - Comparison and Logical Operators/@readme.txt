Lesson 008 :  Comparison and Logical Operators
Reference  : p. 150, 156

Operator         Description
=                equals
!=               not equals
&lt;             <
&lt;=            <=
&gt;             >
&gt=             >=

<xsl:if test="position() &lt; last()"><xsl:text>,</xsl:text></xsl:if>


Logical operators : and, or

phonenumber[position()=1 and @type='home']

NOTE:
 The and operator has precedence over or.  So, A or B and C means
 the B and C must be true or A needs to be true.