see
  DisputeCardTransactionsProcessorTest
  AccountOwnershipHelperImplTest

  CardDisputesDAOImplTest
        Capture<Integer> capturedWorkTypes = new Capture<Integer>(CaptureType.ALL);
