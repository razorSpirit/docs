package com.capitalone.annotated.flow.validator;

// import static org.mockito.Mockito.*;
// import static org.junit.Assert.*;
// import static org.mockito.Matchers.*;
//import static org.mockito.Matchers.any;
//import static org.mockito.Matchers.eq;
//import static org.mockito.Mockito.doNothing;
//import static org.mockito.Mockito.doThrow;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.never;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class CafeAssociateValidatorTest {
    @InjectMocks private NotesRequestConverter converter;

    @Mock CafeAssociateValidator cafeAssociateValidator;
    @Mock private Appender mockAppender;

     private ArgumentCaptor<LoggingEvent> logMessageCaptor;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        Logger.getRootLogger().addAppender(mockAppender);
        logMessageCaptor = ArgumentCaptor.forClass(LoggingEvent.class);
     }

    @After
    public void tearDown() throws Exception {
        logMessageCaptor = null;
     }

    @Test
    public void someTest() {
    }

}
