Tests I wrote
  (*) KidsAccountConversionTransactionProcessorTest
      KidsAccountConversionDAOImplTest
      KidsAccountConversionRequestValidatorTest

      CloseoutDisputeEmailerTest : tests WorkProcess

Must manually add:

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.never;


Issues
  capturing an array 
    see:KidsAccountConversionTransactionProcessorTest.testWriteActivity()

    ArgumentCaptor<Object[]> refs = ArgumentCaptor.forClass(Object[].class);

  capturing map that was called twice 
    see KidsAccountConversionTransactionProcessorTest.testSendEmails()

        verify(mockEmailer, times(2)).execute(params.capture());
        assertEquals(params.getAllValues().get(0).get(ObmClient.TEMPLATE_DOC_ID), processor.getAdultEmailTemplate());
        assertEquals(params.getAllValues().get(1).get(ObmClient.TEMPLATE_DOC_ID), processor.getMinorEmailTemplate());
	
  calling a method that returns void
    see KidsAccountConversionTransactionProcessorTest.testWriteActivity()

        doNothing().when(mockWriter).createActivity(Long.parseLong(INTERACTION_ID),
                ActivitySymbols.ACCOUNT_CONVERTED_TO_KSA, operator, new Integer(CIF), mockRefs.capture());

  static logging
    see KidsAccountConversionTransactionProcessorTest
       Logger.getRootLogger().addAppender(mockAppender);

Mockito
  TransactionProcessor
    KidsAccountConversionTransactionProcessorTest
      params.capture()

  DAO
    KidsAccountConversionDAOImplTest  
 
  Validation
    KidsAccountConversionRequestValidatorTest
        (mock, when, verify, times, never)

PowerMock
  SecurityLockDaoImplTest.java